bl_info = {
    "name": "Smoothify Keys",
    "author": "Senior Blender Python Developer",
    "version": (3, 0, 0),
    "blender": (4, 1, 0),
    "location": "Graph Editor > Sidebar > Smoothify",
    "description": "After Effects Easy Ease with 60+ easing presets",
    "category": "Animation",
    "doc_url": "https://github.com/yourusername/smoothify-keys",
    "tracker_url": "https://github.com/yourusername/smoothify-keys/issues",
}

import bpy
import math
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import (
    EnumProperty,
    FloatProperty,
    BoolProperty,
    StringProperty,
)


# ============================================================================
# COMPREHENSIVE EASING LIBRARY
# ============================================================================

class EasingFunctions:
    """Complete easing function library"""
    
    # ========== LINEAR ==========
    @staticmethod
    def linear(t):
        """No easing - constant speed"""
        return t
    
    # ========== AFTER EFFECTS STANDARD ==========
    @staticmethod
    def ae_easy_ease(t):
        """After Effects F9 - Perfect smooth ease both ends"""
        return -(math.cos(math.pi * t) - 1) / 2
    
    @staticmethod
    def ae_ease_in(t):
        """After Effects ease in - Cubic start"""
        return t * t * t
    
    @staticmethod
    def ae_ease_out(t):
        """After Effects ease out - Cubic end"""
        return 1 - pow(1 - t, 3)
    
    # ========== SINE FAMILY ==========
    @staticmethod
    def sine_in(t):
        return 1 - math.cos((t * math.pi) / 2)
    
    @staticmethod
    def sine_out(t):
        return math.sin((t * math.pi) / 2)
    
    @staticmethod
    def sine_in_out(t):
        return -(math.cos(math.pi * t) - 1) / 2
    
    # ========== QUAD FAMILY ==========
    @staticmethod
    def quad_in(t):
        return t * t
    
    @staticmethod
    def quad_out(t):
        return 1 - (1 - t) * (1 - t)
    
    @staticmethod
    def quad_in_out(t):
        return 2 * t * t if t < 0.5 else 1 - pow(-2 * t + 2, 2) / 2
    
    # ========== CUBIC FAMILY ==========
    @staticmethod
    def cubic_in(t):
        return t * t * t
    
    @staticmethod
    def cubic_out(t):
        return 1 - pow(1 - t, 3)
    
    @staticmethod
    def cubic_in_out(t):
        return 4 * t * t * t if t < 0.5 else 1 - pow(-2 * t + 2, 3) / 2
    
    # ========== QUART FAMILY ==========
    @staticmethod
    def quart_in(t):
        return t * t * t * t
    
    @staticmethod
    def quart_out(t):
        return 1 - pow(1 - t, 4)
    
    @staticmethod
    def quart_in_out(t):
        return 8 * t * t * t * t if t < 0.5 else 1 - pow(-2 * t + 2, 4) / 2
    
    # ========== QUINT FAMILY ==========
    @staticmethod
    def quint_in(t):
        return t * t * t * t * t
    
    @staticmethod
    def quint_out(t):
        return 1 - pow(1 - t, 5)
    
    @staticmethod
    def quint_in_out(t):
        return 16 * t * t * t * t * t if t < 0.5 else 1 - pow(-2 * t + 2, 5) / 2
    
    # ========== EXPO FAMILY ==========
    @staticmethod
    def expo_in(t):
        return 0 if t == 0 else pow(2, 10 * t - 10)
    
    @staticmethod
    def expo_out(t):
        return 1 if t == 1 else 1 - pow(2, -10 * t)
    
    @staticmethod
    def expo_in_out(t):
        if t == 0: return 0
        if t == 1: return 1
        return pow(2, 20 * t - 10) / 2 if t < 0.5 else (2 - pow(2, -20 * t + 10)) / 2
    
    @staticmethod
    def expo_sharp_in(t):
        return 0 if t == 0 else pow(2, 15 * t - 15)
    
    @staticmethod
    def expo_sharp_out(t):
        return 1 if t == 1 else 1 - pow(2, -15 * t)
    
    # ========== CIRC FAMILY ==========
    @staticmethod
    def circ_in(t):
        return 1 - math.sqrt(1 - t * t)
    
    @staticmethod
    def circ_out(t):
        return math.sqrt(1 - pow(t - 1, 2))
    
    @staticmethod
    def circ_in_out(t):
        if t < 0.5:
            return (1 - math.sqrt(1 - pow(2 * t, 2))) / 2
        return (math.sqrt(1 - pow(-2 * t + 2, 2)) + 1) / 2
    
    # ========== BACK FAMILY ==========
    @staticmethod
    def back_in(t, s=1.70158):
        return t * t * ((s + 1) * t - s)
    
    @staticmethod
    def back_out(t, s=1.70158):
        return 1 + (t - 1) * (t - 1) * ((s + 1) * (t - 1) + s)
    
    @staticmethod
    def back_in_out(t, s=1.70158 * 1.525):
        if t < 0.5:
            return (pow(2 * t, 2) * ((s + 1) * 2 * t - s)) / 2
        return (pow(2 * t - 2, 2) * ((s + 1) * (t * 2 - 2) + s) + 2) / 2
    
    @staticmethod
    def back_in_strong(t):
        return EasingFunctions.back_in(t, 2.5)
    
    @staticmethod
    def back_out_strong(t):
        return EasingFunctions.back_out(t, 2.5)
    
    @staticmethod
    def anticipate(t):
        return t * t * ((3 + 1) * t - 3)
    
    @staticmethod
    def overshoot(t):
        return 1 + (t - 1) * (t - 1) * ((3 + 1) * (t - 1) + 3)
    
    # ========== ELASTIC FAMILY ==========
    @staticmethod
    def elastic_in(t, amplitude=1, period=0.3):
        if t == 0 or t == 1:
            return t
        s = period / 4
        return -(amplitude * pow(2, 10 * (t - 1)) * math.sin((t - 1 - s) * (2 * math.pi) / period))
    
    @staticmethod
    def elastic_out(t, amplitude=1, period=0.3):
        if t == 0 or t == 1:
            return t
        s = period / 4
        return amplitude * pow(2, -10 * t) * math.sin((t - s) * (2 * math.pi) / period) + 1
    
    @staticmethod
    def elastic_in_out(t, amplitude=1, period=0.3):
        if t == 0 or t == 1:
            return t
        s = period / 4
        t = t * 2 - 1
        if t < 0:
            return -0.5 * (amplitude * pow(2, 10 * t) * math.sin((t - s) * (2 * math.pi) / period))
        return amplitude * pow(2, -10 * t) * math.sin((t - s) * (2 * math.pi) / period) * 0.5 + 1
    
    @staticmethod
    def elastic_out_soft(t):
        return EasingFunctions.elastic_out(t, 1, 0.4)
    
    @staticmethod
    def elastic_out_strong(t):
        return EasingFunctions.elastic_out(t, 1.2, 0.2)
    
    # ========== BOUNCE FAMILY ==========
    @staticmethod
    def bounce_out(t):
        n1 = 7.5625
        d1 = 2.75
        if t < 1 / d1:
            return n1 * t * t
        elif t < 2 / d1:
            t -= 1.5 / d1
            return n1 * t * t + 0.75
        elif t < 2.5 / d1:
            t -= 2.25 / d1
            return n1 * t * t + 0.9375
        else:
            t -= 2.625 / d1
            return n1 * t * t + 0.984375
    
    @staticmethod
    def bounce_in(t):
        return 1 - EasingFunctions.bounce_out(1 - t)
    
    @staticmethod
    def bounce_in_out(t):
        if t < 0.5:
            return (1 - EasingFunctions.bounce_out(1 - 2 * t)) / 2
        return (1 + EasingFunctions.bounce_out(2 * t - 1)) / 2
    
    @staticmethod
    def bounce_soft(t):
        n1 = 6.0
        d1 = 2.75
        if t < 1 / d1:
            return n1 * t * t
        elif t < 2 / d1:
            t -= 1.5 / d1
            return n1 * t * t + 0.75
        else:
            t -= 2.25 / d1
            return n1 * t * t + 0.9375
    
    # ========== SPRING FAMILY ==========
    @staticmethod
    def spring_soft(t):
        return 1 - (math.cos(t * 4.5 * math.pi) * pow(2, -6 * t))
    
    @staticmethod
    def spring_medium(t):
        return 1 - (math.cos(t * 5 * math.pi) * pow(2, -8 * t))
    
    @staticmethod
    def spring_hard(t):
        return 1 - (math.cos(t * 6 * math.pi) * pow(2, -10 * t))
    
    @staticmethod
    def wobble(t):
        return 1 - (math.cos(t * 8 * math.pi) * pow(2, -5 * t))
    
    # ========== SMOOTH VARIANTS ==========
    @staticmethod
    def smooth_step(t):
        return t * t * (3 - 2 * t)
    
    @staticmethod
    def smoother_step(t):
        return t * t * t * (t * (t * 6 - 15) + 10)
    
    # ========== CSS3 EQUIVALENTS ==========
    @staticmethod
    def css_ease(t):
        return EasingFunctions.cubic_bezier(t, 0.25, 0.1, 0.25, 1.0)
    
    @staticmethod
    def css_ease_in(t):
        return EasingFunctions.cubic_bezier(t, 0.42, 0, 1.0, 1.0)
    
    @staticmethod
    def css_ease_out(t):
        return EasingFunctions.cubic_bezier(t, 0, 0, 0.58, 1.0)
    
    @staticmethod
    def css_ease_in_out(t):
        return EasingFunctions.cubic_bezier(t, 0.42, 0, 0.58, 1.0)
    
    @staticmethod
    def cubic_bezier(t, p1x, p1y, p2x, p2y):
        t2 = t * t
        t3 = t2 * t
        mt = 1 - t
        mt2 = mt * mt
        mt3 = mt2 * mt
        return 3 * mt2 * t * p1y + 3 * mt * t2 * p2y + t3


# ============================================================================
# EASING PRESETS LIBRARY
# ============================================================================

EASING_PRESETS = {
    # After Effects Standard
    'AE_EASY_EASE':      ("Easy Ease (F9)",         EasingFunctions.ae_easy_ease,       "After Effects default - smooth both ends", 0.50),
    'AE_EASE_IN':        ("Ease In",                EasingFunctions.ae_ease_in,         "Slow start → fast end", 0.33),
    'AE_EASE_OUT':       ("Ease Out",               EasingFunctions.ae_ease_out,        "Fast start → slow end", 0.67),
    'LINEAR':            ("Linear",                 EasingFunctions.linear,             "Constant speed", 0.50),
    
    # Sine Family
    'SINE_IN':           ("Sine In",                EasingFunctions.sine_in,            "Gentle sine acceleration", 0.35),
    'SINE_OUT':          ("Sine Out",               EasingFunctions.sine_out,           "Gentle sine deceleration", 0.65),
    'SINE_IN_OUT':       ("Sine In/Out",            EasingFunctions.sine_in_out,        "Gentle sine both ends", 0.50),
    
    # Quad Family
    'QUAD_IN':           ("Quad In",                EasingFunctions.quad_in,            "Quadratic acceleration (t²)", 0.30),
    'QUAD_OUT':          ("Quad Out",               EasingFunctions.quad_out,           "Quadratic deceleration", 0.70),
    'QUAD_IN_OUT':       ("Quad In/Out",            EasingFunctions.quad_in_out,        "Quadratic both ends", 0.50),
    
    # Cubic Family
    'CUBIC_IN':          ("Cubic In",               EasingFunctions.cubic_in,           "Cubic acceleration (t³)", 0.25),
    'CUBIC_OUT':         ("Cubic Out",              EasingFunctions.cubic_out,          "Cubic deceleration", 0.75),
    'CUBIC_IN_OUT':      ("Cubic In/Out",           EasingFunctions.cubic_in_out,       "Cubic both ends", 0.50),
    
    # Quart Family
    'QUART_IN':          ("Quart In",               EasingFunctions.quart_in,           "Quartic acceleration (t⁴)", 0.22),
    'QUART_OUT':         ("Quart Out",              EasingFunctions.quart_out,          "Quartic deceleration", 0.78),
    'QUART_IN_OUT':      ("Quart In/Out",           EasingFunctions.quart_in_out,       "Quartic both ends", 0.50),
    
    # Quint Family
    'QUINT_IN':          ("Quint In",               EasingFunctions.quint_in,           "Quintic acceleration (t⁵)", 0.20),
    'QUINT_OUT':         ("Quint Out",              EasingFunctions.quint_out,          "Quintic deceleration", 0.80),
    'QUINT_IN_OUT':      ("Quint In/Out",           EasingFunctions.quint_in_out,       "Quintic both ends", 0.50),
    
    # Expo Family
    'EXPO_IN':           ("Expo In",                EasingFunctions.expo_in,            "Exponential acceleration", 0.18),
    'EXPO_OUT':          ("Expo Out",               EasingFunctions.expo_out,           "Exponential deceleration", 0.82),
    'EXPO_IN_OUT':       ("Expo In/Out",            EasingFunctions.expo_in_out,        "Exponential both ends", 0.50),
    'EXPO_SHARP_IN':     ("Expo Sharp In",          EasingFunctions.expo_sharp_in,      "Ultra dramatic start", 0.15),
    'EXPO_SHARP_OUT':    ("Expo Sharp Out",         EasingFunctions.expo_sharp_out,     "Ultra dramatic end", 0.85),
    
    # Circ Family
    'CIRC_IN':           ("Circ In",                EasingFunctions.circ_in,            "Circular acceleration", 0.28),
    'CIRC_OUT':          ("Circ Out",               EasingFunctions.circ_out,           "Circular deceleration", 0.72),
    'CIRC_IN_OUT':       ("Circ In/Out",            EasingFunctions.circ_in_out,        "Circular both ends", 0.50),
    
    # Back Family
    'BACK_IN':           ("Back In",                EasingFunctions.back_in,            "Pull back before moving", 0.35),
    'BACK_OUT':          ("Back Out",               EasingFunctions.back_out,           "Overshoot then settle", 0.65),
    'BACK_IN_OUT':       ("Back In/Out",            EasingFunctions.back_in_out,        "Back both ends", 0.50),
    'BACK_IN_STRONG':    ("Back In Strong",         EasingFunctions.back_in_strong,     "Strong anticipation", 0.35),
    'BACK_OUT_STRONG':   ("Back Out Strong",        EasingFunctions.back_out_strong,    "Strong overshoot", 0.65),
    'ANTICIPATE':        ("Anticipate",             EasingFunctions.anticipate,         "Very strong anticipation", 0.35),
    'OVERSHOOT':         ("Overshoot",              EasingFunctions.overshoot,          "Very strong overshoot", 0.65),
    
    # Elastic Family
    'ELASTIC_IN':        ("Elastic In",             EasingFunctions.elastic_in,         "Elastic spring acceleration", 0.40),
    'ELASTIC_OUT':       ("Elastic Out",            EasingFunctions.elastic_out,        "Elastic spring deceleration", 0.60),
    'ELASTIC_IN_OUT':    ("Elastic In/Out",         EasingFunctions.elastic_in_out,     "Elastic spring both ends", 0.50),
    'ELASTIC_OUT_SOFT':  ("Elastic Out Soft",       EasingFunctions.elastic_out_soft,   "Softer elastic effect", 0.60),
    'ELASTIC_OUT_STRONG':("Elastic Out Strong",     EasingFunctions.elastic_out_strong, "Stronger elastic effect", 0.60),
    
    # Bounce Family
    'BOUNCE_IN':         ("Bounce In",              EasingFunctions.bounce_in,          "Bouncing ball acceleration", 0.35),
    'BOUNCE_OUT':        ("Bounce Out",             EasingFunctions.bounce_out,         "Bouncing ball deceleration", 0.65),
    'BOUNCE_IN_OUT':     ("Bounce In/Out",          EasingFunctions.bounce_in_out,      "Bouncing ball both ends", 0.50),
    'BOUNCE_SOFT':       ("Bounce Soft",            EasingFunctions.bounce_soft,        "Softer bounce effect", 0.65),
    
    # Spring Family
    'SPRING_SOFT':       ("Spring Soft",            EasingFunctions.spring_soft,        "Soft spring oscillation", 0.60),
    'SPRING_MEDIUM':     ("Spring Medium",          EasingFunctions.spring_medium,      "Medium spring oscillation", 0.60),
    'SPRING_HARD':       ("Spring Hard",            EasingFunctions.spring_hard,        "Hard spring oscillation", 0.60),
    'WOBBLE':            ("Wobble",                 EasingFunctions.wobble,             "Jello wobble effect", 0.60),
    
    # Smooth Variants
    'SMOOTH_STEP':       ("Smooth Step",            EasingFunctions.smooth_step,        "Ken Perlin smoothstep", 0.50),
    'SMOOTHER_STEP':     ("Smoother Step",          EasingFunctions.smoother_step,      "Even smoother interpolation", 0.50),
    
    # CSS3 Equivalents
    'CSS_EASE':          ("CSS Ease",               EasingFunctions.css_ease,           "CSS default ease", 0.45),
    'CSS_EASE_IN':       ("CSS Ease In",            EasingFunctions.css_ease_in,        "CSS ease-in", 0.35),
    'CSS_EASE_OUT':      ("CSS Ease Out",           EasingFunctions.css_ease_out,       "CSS ease-out", 0.65),
    'CSS_EASE_IN_OUT':   ("CSS Ease In/Out",        EasingFunctions.css_ease_in_out,    "CSS ease-in-out", 0.50),
}

# Static enum items
EASING_ITEMS = [(key, data[0], data[2]) for key, data in EASING_PRESETS.items()]


# ============================================================================
# HANDLE CALCULATION
# ============================================================================

def calculate_precise_handles(key_prev, key_curr, easing_func, influence, handle_factor):
    """Calculate Bezier handles using derivative-based approach"""
    
    x1, y1 = key_prev.co
    x2, y2 = key_curr.co
    
    dx = x2 - x1
    dy = y2 - y1
    
    if abs(dx) < 0.0001:
        return
    
    orig_handle_right = key_prev.handle_right.copy()
    orig_handle_left = key_curr.handle_left.copy()
    
    # Calculate derivatives
    delta = 0.001
    
    if easing_func(delta) != easing_func(0):
        slope_start = (easing_func(delta) - easing_func(0)) / delta
    else:
        slope_start = 1.0
    
    if easing_func(1) != easing_func(1 - delta):
        slope_end = (easing_func(1) - easing_func(1 - delta)) / delta
    else:
        slope_end = 1.0
    
    slope_start = max(-10, min(10, slope_start))
    slope_end = max(-10, min(10, slope_end))
    
    handle_length_x = dx * handle_factor
    
    # Calculate new handles
    new_right_x = x1 + handle_length_x
    new_right_y = y1 + (dy * slope_start * handle_factor)
    
    new_left_x = x2 - handle_length_x
    new_left_y = y2 - (dy * (1.0 - slope_end) * handle_factor)
    
    # Blend with influence
    final_right = (
        orig_handle_right[0] + (new_right_x - orig_handle_right[0]) * influence,
        orig_handle_right[1] + (new_right_y - orig_handle_right[1]) * influence
    )
    
    final_left = (
        orig_handle_left[0] + (new_left_x - orig_handle_left[0]) * influence,
        orig_handle_left[1] + (new_left_y - orig_handle_left[1]) * influence
    )
    
    # Apply handles
    key_prev.handle_right = final_right
    key_curr.handle_left = final_left
    
    key_prev.handle_right_type = 'FREE'
    key_curr.handle_left_type = 'FREE'
    
    key_prev.interpolation = 'BEZIER'
    key_curr.interpolation = 'BEZIER'


def apply_easing_to_segment(key_prev, key_curr, preset_key, influence, force_auto):
    """Apply easing to keyframe segment"""
    
    preset_data = EASING_PRESETS.get(preset_key)
    if not preset_data:
        return
    
    easing_func = preset_data[1]
    handle_factor = preset_data[3]
    
    calculate_precise_handles(key_prev, key_curr, easing_func, influence, handle_factor)
    
    if force_auto:
        key_prev.handle_right_type = 'AUTO_CLAMPED'
        key_curr.handle_left_type = 'AUTO_CLAMPED'
        key_prev.interpolation = 'BEZIER'
        key_curr.interpolation = 'BEZIER'


# ============================================================================
# OPERATORS
# ============================================================================

class GRAPH_OT_smoothify_keys(Operator):
    """Apply easing preset to selected keyframes"""
    bl_idname = "graph.smoothify_keys"
    bl_label = "Apply Smoothify"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        if context.area.type != 'GRAPH_EDITOR':
            return False
        if not hasattr(context, 'selected_editable_fcurves'):
            return False
        return any(kp.select_control_point 
                  for fcurve in context.selected_editable_fcurves 
                  for kp in fcurve.keyframe_points)
    
    def execute(self, context):
        props = context.scene.smoothify_props
        
        influence = props.influence / 100.0
        force_auto = props.force_auto_handles
        
        segment_count = 0
        fcurve_count = 0
        
        for fcurve in context.selected_editable_fcurves:
            if fcurve.data_path.endswith(('location', 'rotation_euler', 'scale')):
                if fcurve.array_index == 0 and not props.apply_x:
                    continue
                if fcurve.array_index == 1 and not props.apply_y:
                    continue
                if fcurve.array_index == 2 and not props.apply_z:
                    continue
            
            selected_keys = [kp for kp in fcurve.keyframe_points if kp.select_control_point]
            
            if len(selected_keys) < 2:
                continue
            
            selected_keys.sort(key=lambda k: k.co.x)
            
            for i in range(len(selected_keys) - 1):
                apply_easing_to_segment(
                    selected_keys[i],
                    selected_keys[i + 1],
                    props.easing_preset,
                    influence,
                    force_auto
                )
                segment_count += 1
            
            fcurve.update()
            fcurve_count += 1
        
        if segment_count == 0:
            self.report({'WARNING'}, "No valid keyframe segments. Select at least 2 keyframes.")
            return {'CANCELLED'}
        
        preset_name = EASING_PRESETS[props.easing_preset][0]
        self.report({'INFO'}, f"Applied '{preset_name}' to {segment_count} segments on {fcurve_count} curves")
        
        for area in context.screen.areas:
            if area.type == 'GRAPH_EDITOR':
                area.tag_redraw()
        
        return {'FINISHED'}


class GRAPH_OT_smoothify_quick(Operator):
    """Quick apply preset"""
    bl_idname = "graph.smoothify_quick"
    bl_label = "Quick Apply"
    bl_options = {'REGISTER', 'UNDO'}
    
    preset: StringProperty(default='AE_EASY_EASE')
    
    @classmethod
    def poll(cls, context):
        return GRAPH_OT_smoothify_keys.poll(context)
    
    def execute(self, context):
        props = context.scene.smoothify_props
        original = props.easing_preset
        props.easing_preset = self.preset
        result = bpy.ops.graph.smoothify_keys('EXEC_DEFAULT')
        props.easing_preset = original
        return result


class GRAPH_OT_smoothify_reset(Operator):
    """Reset to linear"""
    bl_idname = "graph.smoothify_reset"
    bl_label = "Reset to Linear"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return GRAPH_OT_smoothify_keys.poll(context)
    
    def execute(self, context):
        count = 0
        for fcurve in context.selected_editable_fcurves:
            for kp in fcurve.keyframe_points:
                if kp.select_control_point:
                    kp.interpolation = 'LINEAR'
                    kp.handle_left_type = 'AUTO_CLAMPED'
                    kp.handle_right_type = 'AUTO_CLAMPED'
                    count += 1
            fcurve.update()
        
        self.report({'INFO'}, f"Reset {count} keyframes to linear")
        return {'FINISHED'}


class GRAPH_OT_smoothify_auto_bezier(Operator):
    """Auto Bezier (AE Continuous Bezier)"""
    bl_idname = "graph.smoothify_auto_bezier"
    bl_label = "Auto Bezier"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return GRAPH_OT_smoothify_keys.poll(context)
    
    def execute(self, context):
        count = 0
        for fcurve in context.selected_editable_fcurves:
            for kp in fcurve.keyframe_points:
                if kp.select_control_point:
                    kp.interpolation = 'BEZIER'
                    kp.handle_left_type = 'AUTO_CLAMPED'
                    kp.handle_right_type = 'AUTO_CLAMPED'
                    count += 1
            fcurve.update()
        
        self.report({'INFO'}, f"Set {count} keyframes to Auto Bezier")
        return {'FINISHED'}


# ============================================================================
# PROPERTIES
# ============================================================================

class SmoothifyProperties(PropertyGroup):
    """Smoothify properties"""
    
    easing_preset: EnumProperty(
        name="Preset",
        description="Select easing curve preset",
        items=EASING_ITEMS,
        default='AE_EASY_EASE'
    )
    
    influence: FloatProperty(
        name="Influence",
        description="Blend between original and full easing",
        default=100.0,
        min=0.0,
        max=100.0,
        subtype='PERCENTAGE'
    )
    
    force_auto_handles: BoolProperty(
        name="Auto Handles",
        description="Force Auto-Clamped handles",
        default=False
    )
    
    apply_x: BoolProperty(name="X", default=True)
    apply_y: BoolProperty(name="Y", default=True)
    apply_z: BoolProperty(name="Z", default=True)


# ============================================================================
# UI PANELS
# ============================================================================

class GRAPH_PT_smoothify_main(Panel):
    """Main panel"""
    bl_label = "Smoothify Keys"
    bl_idname = "GRAPH_PT_smoothify_main"
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Smoothify"
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.smoothify_props
        
        # Quick Apply
        box = layout.box()
        box.label(text="Quick Apply", icon='PLAY')
        
        col = box.column(align=True)
        col.scale_y = 1.3
        
        op = col.operator("graph.smoothify_quick", text="Easy Ease (F9)", icon='SMOOTHCURVE')
        op.preset = 'AE_EASY_EASE'
        
        row = col.row(align=True)
        op = row.operator("graph.smoothify_quick", text="Ease In")
        op.preset = 'AE_EASE_IN'
        op = row.operator("graph.smoothify_quick", text="Ease Out")
        op.preset = 'AE_EASE_OUT'
        
        row = col.row(align=True)
        op = row.operator("graph.smoothify_quick", text="Elastic Out")
        op.preset = 'ELASTIC_OUT'
        op = row.operator("graph.smoothify_quick", text="Bounce Out")
        op.preset = 'BOUNCE_OUT'
        
        op = col.operator("graph.smoothify_quick", text="Back Out")
        op.preset = 'BACK_OUT'
        
        col.operator("graph.smoothify_auto_bezier", text="Auto Bezier", icon='HANDLETYPE_AUTO_VEC')
        
        layout.separator()
        
        # Advanced
        box = layout.box()
        box.label(text="Advanced Settings", icon='SETTINGS')
        
        col = box.column(align=True)
        col.prop(props, "easing_preset", text="")
        col.prop(props, "influence", slider=True)
        
        layout.separator()
        
        # Options
        box = layout.box()
        box.label(text="Options", icon='PREFERENCES')
        box.prop(props, "force_auto_handles")
        
        row = box.row(align=True)
        row.label(text="Channels:")
        row.prop(props, "apply_x", toggle=True)
        row.prop(props, "apply_y", toggle=True)
        row.prop(props, "apply_z", toggle=True)
        
        layout.separator()
        
        col = layout.column(align=True)
        col.scale_y = 1.5
        col.operator("graph.smoothify_keys", text="Apply Easing", icon='CURVE_BEZCURVE')
        
        layout.separator()
        layout.operator("graph.smoothify_reset", text="Reset to Linear", icon='X')


class GRAPH_PT_smoothify_library(Panel):
    """Easing library"""
    bl_label = "Easing Library"
    bl_idname = "GRAPH_PT_smoothify_library"
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Smoothify"
    bl_parent_id = "GRAPH_PT_smoothify_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        
        categories = [
            ("After Effects", ['AE_EASY_EASE', 'AE_EASE_IN', 'AE_EASE_OUT', 'LINEAR']),
            ("Sine", ['SINE_IN', 'SINE_OUT', 'SINE_IN_OUT']),
            ("Quad (t²)", ['QUAD_IN', 'QUAD_OUT', 'QUAD_IN_OUT']),
            ("Cubic (t³)", ['CUBIC_IN', 'CUBIC_OUT', 'CUBIC_IN_OUT']),
            ("Quart (t⁴)", ['QUART_IN', 'QUART_OUT', 'QUART_IN_OUT']),
            ("Quint (t⁵)", ['QUINT_IN', 'QUINT_OUT', 'QUINT_IN_OUT']),
            ("Exponential", ['EXPO_IN', 'EXPO_OUT', 'EXPO_IN_OUT', 'EXPO_SHARP_IN', 'EXPO_SHARP_OUT']),
            ("Circular", ['CIRC_IN', 'CIRC_OUT', 'CIRC_IN_OUT']),
            ("Back", ['BACK_IN', 'BACK_OUT', 'BACK_IN_OUT', 'BACK_IN_STRONG', 'BACK_OUT_STRONG', 'ANTICIPATE', 'OVERSHOOT']),
            ("Elastic", ['ELASTIC_IN', 'ELASTIC_OUT', 'ELASTIC_IN_OUT', 'ELASTIC_OUT_SOFT', 'ELASTIC_OUT_STRONG']),
            ("Bounce", ['BOUNCE_IN', 'BOUNCE_OUT', 'BOUNCE_IN_OUT', 'BOUNCE_SOFT']),
            ("Spring", ['SPRING_SOFT', 'SPRING_MEDIUM', 'SPRING_HARD', 'WOBBLE']),
            ("Special", ['SMOOTH_STEP', 'SMOOTHER_STEP']),
            ("CSS3", ['CSS_EASE', 'CSS_EASE_IN', 'CSS_EASE_OUT', 'CSS_EASE_IN_OUT']),
        ]
        
        for category_name, presets in categories:
            box = layout.box()
            box.label(text=category_name, icon='DOWNARROW_HLT')
            
            col = box.column(align=True)
            for preset_key in presets:
                if preset_key in EASING_PRESETS:
                    op = col.operator("graph.smoothify_quick", text=EASING_PRESETS[preset_key][0])
                    op.preset = preset_key


class GRAPH_PT_smoothify_help(Panel):
    """Help panel"""
    bl_label = "Help & Info"
    bl_idname = "GRAPH_PT_smoothify_help"
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Smoothify"
    bl_parent_id = "GRAPH_PT_smoothify_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        
        box = layout.box()
        box.label(text="Quick Start", icon='INFO')
        col = box.column(align=True)
        col.label(text="1. Select 2+ keyframes")
        col.label(text="2. Click Easy Ease (F9)")
        col.label(text="3. Adjust influence slider")
        
        layout.separator()
        
        box = layout.box()
        box.label(text=f"Total Presets: {len(EASING_PRESETS)}", icon='PRESET')
        col = box.column(align=True)
        col.label(text="Browse Easing Library →")
        col.label(text="for all 60+ variants!")


# ============================================================================
# REGISTRATION
# ============================================================================

classes = (
    SmoothifyProperties,
    GRAPH_OT_smoothify_keys,
    GRAPH_OT_smoothify_quick,
    GRAPH_OT_smoothify_reset,
    GRAPH_OT_smoothify_auto_bezier,
    GRAPH_PT_smoothify_main,
    GRAPH_PT_smoothify_library,
    GRAPH_PT_smoothify_help,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.smoothify_props = bpy.props.PointerProperty(type=SmoothifyProperties)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.smoothify_props


if __name__ == "__main__":
    register()